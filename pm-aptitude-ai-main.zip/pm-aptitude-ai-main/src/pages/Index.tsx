import { useState } from "react";
import HeroSection from "@/components/HeroSection";
import Navigation from "@/components/Navigation";
import Dashboard from "@/components/Dashboard";

const Index = () => {
  const [showDashboard, setShowDashboard] = useState(false);

  if (showDashboard) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <Dashboard />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div 
        className="cursor-pointer" 
        onClick={() => setShowDashboard(true)}
        title="Click to view dashboard prototype"
      >
        <HeroSection />
      </div>
    </div>
  );
};

export default Index;
