import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Filter, Search, SlidersHorizontal, Sparkles, Target, TrendingUp } from "lucide-react";
import InternshipCard from "./InternshipCard";

const Dashboard = () => {
  const mockInternships = [
    {
      company: "TechCorp",
      title: "Product Management Intern",
      location: "San Francisco, CA",
      duration: "3 months",
      compensation: "$2,000/month",
      matchPercentage: 96,
      skills: ["Product Strategy", "Data Analysis", "User Research", "Agile"],
      description: "Join our product team to work on cutting-edge SaaS products used by millions of users worldwide. You'll collaborate with engineering and design teams.",
      isNew: true,
    },
    {
      company: "StartupX",
      title: "Associate Product Manager Intern",
      location: "New York, NY",
      duration: "4 months",
      compensation: "$1,800/month",
      matchPercentage: 92,
      skills: ["Market Research", "Roadmapping", "Stakeholder Management"],
      description: "Help build the next generation of fintech products. Work directly with our CPO and gain hands-on experience in product development.",
      isRemote: true,
    },
    {
      company: "InnovateNow",
      title: "Junior Product Manager Intern",
      location: "Austin, TX",
      duration: "6 months",
      compensation: "$2,200/month",
      matchPercentage: 89,
      skills: ["A/B Testing", "Analytics", "Customer Interviews", "Wireframing"],
      description: "Drive product initiatives for our growing e-commerce platform. Learn from experienced PMs while working on real product challenges.",
    },
    {
      company: "FutureCore",
      title: "Product Strategy Intern",
      location: "Seattle, WA",
      duration: "3 months",
      compensation: "$2,500/month",
      matchPercentage: 87,
      skills: ["Strategic Planning", "Competitive Analysis", "Go-to-Market"],
      description: "Support strategic product decisions for our AI-powered enterprise solutions. Perfect for candidates interested in B2B products.",
      isNew: true,
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card-gradient border-b border-border/50">
        <div className="container mx-auto px-6 py-8">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">
                Welcome back, Alex! 👋
              </h1>
              <p className="text-muted-foreground">
                We found <span className="text-primary font-semibold">12 new matches</span> for you today
              </p>
            </div>
            
            <div className="flex items-center space-x-4">
              <Card className="bg-primary/10 border-primary/20">
                <CardContent className="flex items-center space-x-3 p-4">
                  <Target className="w-6 h-6 text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Match Score</p>
                    <p className="text-lg font-bold text-primary">92%</p>
                  </div>
                </CardContent>
              </Card>
              
              <Button className="bg-primary hover:bg-primary/90">
                <Sparkles className="w-4 h-4 mr-2" />
                Update Preferences
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Applications Sent</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">24</div>
              <p className="text-xs text-muted-foreground">+3 from last week</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Interview Invites</CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">7</div>
              <p className="text-xs text-muted-foreground">29% conversion rate</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Saved Positions</CardTitle>
              <Sparkles className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">15</div>
              <p className="text-xs text-muted-foreground">+5 this week</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Search */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search by company, role, or skills..."
              className="pl-10"
            />
          </div>
          
          <div className="flex space-x-2">
            <Button variant="outline" size="default">
              <Filter className="w-4 h-4 mr-2" />
              Filters
            </Button>
            <Button variant="outline" size="default">
              <SlidersHorizontal className="w-4 h-4 mr-2" />
              Sort
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="recommended" className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="recommended">Recommended</TabsTrigger>
            <TabsTrigger value="saved">Saved</TabsTrigger>
            <TabsTrigger value="applied">Applied</TabsTrigger>
          </TabsList>
          
          <TabsContent value="recommended" className="mt-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">AI Recommended for You</h2>
              <div className="flex space-x-2">
                <Badge variant="secondary">High Match</Badge>
                <Badge variant="outline">New Today</Badge>
              </div>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {mockInternships.map((internship, index) => (
                <InternshipCard key={index} {...internship} />
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="saved" className="mt-6">
            <div className="text-center py-12">
              <p className="text-muted-foreground">Your saved internships will appear here</p>
            </div>
          </TabsContent>
          
          <TabsContent value="applied" className="mt-6">
            <div className="text-center py-12">
              <p className="text-muted-foreground">Track your application status here</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Dashboard;