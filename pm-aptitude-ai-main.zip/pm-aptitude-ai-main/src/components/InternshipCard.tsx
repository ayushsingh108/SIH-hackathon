import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Building, Clock, DollarSign, MapPin, Star, Zap } from "lucide-react";

interface InternshipCardProps {
  company: string;
  logo?: string;
  title: string;
  location: string;
  duration: string;
  compensation: string;
  matchPercentage: number;
  skills: string[];
  description: string;
  isRemote?: boolean;
  isNew?: boolean;
}

const InternshipCard = ({
  company,
  title,
  location,
  duration,
  compensation,
  matchPercentage,
  skills,
  description,
  isRemote = false,
  isNew = false,
}: InternshipCardProps) => {
  return (
    <Card className="bg-card-gradient border-border/50 hover:shadow-glow transition-all duration-300 group hover:-translate-y-1">
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
              <Building className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-lg text-foreground group-hover:text-primary transition-colors">
                {title}
              </h3>
              <p className="text-muted-foreground">{company}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            {isNew && (
              <Badge variant="secondary" className="bg-success text-success-foreground">
                New
              </Badge>
            )}
            <div className="flex items-center space-x-1 bg-primary/20 px-3 py-1 rounded-full">
              <Zap className="w-4 h-4 text-primary" />
              <span className="text-sm font-semibold text-primary">{matchPercentage}% Match</span>
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="pb-4">
        <p className="text-muted-foreground text-sm mb-4 line-clamp-2">{description}</p>
        
        <div className="space-y-3">
          <div className="flex items-center text-sm text-muted-foreground">
            <MapPin className="w-4 h-4 mr-2" />
            <span>{location}</span>
            {isRemote && (
              <Badge variant="outline" className="ml-2 text-xs">Remote</Badge>
            )}
          </div>
          
          <div className="flex items-center text-sm text-muted-foreground">
            <Clock className="w-4 h-4 mr-2" />
            <span>{duration}</span>
          </div>
          
          <div className="flex items-center text-sm text-muted-foreground">
            <DollarSign className="w-4 h-4 mr-2" />
            <span>{compensation}</span>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 mt-4">
          {skills.slice(0, 3).map((skill) => (
            <Badge key={skill} variant="secondary" className="text-xs">
              {skill}
            </Badge>
          ))}
          {skills.length > 3 && (
            <Badge variant="outline" className="text-xs">
              +{skills.length - 3} more
            </Badge>
          )}
        </div>
      </CardContent>

      <CardFooter className="pt-4 border-t border-border/50">
        <div className="flex items-center justify-between w-full">
          <div className="flex items-center text-sm text-muted-foreground">
            <Star className="w-4 h-4 mr-1 text-warning fill-current" />
            <span>4.8 rating</span>
          </div>
          
          <div className="space-x-2">
            <Button variant="outline" size="sm">
              Save
            </Button>
            <Button size="sm" className="bg-primary hover:bg-primary/90">
              Apply Now
            </Button>
          </div>
        </div>
      </CardFooter>
    </Card>
  );
};

export default InternshipCard;