import { Button } from "@/components/ui/button";
import { Sparkles, Target, TrendingUp, Users } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen bg-hero-gradient overflow-hidden">
      <div className="absolute inset-0 bg-black/20" />
      
      {/* Animated background elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-10 w-32 h-32 bg-primary-glow rounded-full blur-xl animate-pulse" />
        <div className="absolute top-40 right-20 w-24 h-24 bg-info rounded-full blur-lg animate-bounce" />
        <div className="absolute bottom-32 left-1/4 w-40 h-40 bg-primary rounded-full blur-2xl animate-pulse" />
      </div>

      <div className="relative z-10 container mx-auto px-6 pt-32 pb-20">
        <div className="text-center max-w-4xl mx-auto">
          <div className="flex items-center justify-center mb-6">
            <Sparkles className="w-8 h-8 text-primary-glow mr-3" />
            <span className="text-primary-glow text-lg font-semibold">AI-Powered Matching</span>
          </div>
          
          <h1 className="text-6xl md:text-7xl font-bold text-white mb-6 leading-tight">
            Find Your Perfect
            <span className="bg-accent-gradient bg-clip-text text-transparent"> PM Internship</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-200 mb-12 leading-relaxed">
            Our advanced AI analyzes your skills, preferences, and career goals to match you 
            with product management internships that accelerate your growth.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <Button size="lg" className="bg-white text-primary hover:bg-gray-100 text-lg px-8 py-4">
              Get Started Free
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              className="border-white text-white hover:bg-white/10 text-lg px-8 py-4"
            >
              See How It Works
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto">
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Target className="w-6 h-6 text-primary-glow mr-2" />
                <span className="text-3xl font-bold text-white">98%</span>
              </div>
              <p className="text-gray-300">Match Accuracy</p>
            </div>
            
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Users className="w-6 h-6 text-primary-glow mr-2" />
                <span className="text-3xl font-bold text-white">2,500+</span>
              </div>
              <p className="text-gray-300">Active Companies</p>
            </div>
            
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <TrendingUp className="w-6 h-6 text-primary-glow mr-2" />
                <span className="text-3xl font-bold text-white">4.9x</span>
              </div>
              <p className="text-gray-300">Faster Placement</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;